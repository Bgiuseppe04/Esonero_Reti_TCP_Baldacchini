
/*
 ============================================================================
 Name        : Client_Baldacchini.h
 Author      : Baldacchini G.
 Version     :
 Copyright   : Your copyright notice
 Description : Header File of the Data.
 ============================================================================
 */
#ifndef DATA_H_
#define DATA_H_

typedef struct{
	char t;//type
	int l;//lenght
}client_input;

#endif
